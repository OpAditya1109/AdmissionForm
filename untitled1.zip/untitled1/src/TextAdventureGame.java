import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TextAdventureGame extends JFrame implements ActionListener {
    private JLabel titleLabel;
    private JButton denseTreesButton, sparklingStreamButton;

    public TextAdventureGame() {
        setTitle("Indian Adventure");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(730, 300);
        setLocationRelativeTo(null);

        titleLabel = new JLabel("Welcome to the Indian Adventure! You find yourself in a mystical forest in India.");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));

        denseTreesButton = new JButton("Path through Dense Trees");
        sparklingStreamButton = new JButton("Path along Sparkling Stream");

        Dimension buttonSize = new Dimension(250, 50);
        denseTreesButton.setPreferredSize(buttonSize);
        sparklingStreamButton.setPreferredSize(buttonSize);


        Font buttonFont = new Font("Arial", Font.BOLD, 16);
        denseTreesButton.setFont(buttonFont);
        sparklingStreamButton.setFont(buttonFont);

        denseTreesButton.addActionListener(this);
        sparklingStreamButton.addActionListener(this);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1));
        panel.add(titleLabel);
        panel.add(denseTreesButton);
        panel.add(sparklingStreamButton);

        add(panel);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == denseTreesButton) {
            JOptionPane.showMessageDialog(this, "You chose the path through the dense trees.\nYou hear the whispers of ancient spirits among the trees.");
            int choice = JOptionPane.showOptionDialog(this,
                    "As you venture deeper, you encounter a sacred temple hidden within the foliage.\nWhat will you do?",
                    "Choose an option",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    new String[]{"Explore the temple", "Continue on the path"},
                    "Explore the temple");
            if (choice == JOptionPane.YES_OPTION) {
                JOptionPane.showMessageDialog(this, "You explore the temple and uncover ancient artifacts filled with mystic powers.\nCongratulations! You've unlocked the secrets of the forest!");
            } else {
                JOptionPane.showMessageDialog(this, "You continue on your path, but the mysteries of the forest linger in your mind.\nYour journey continues...");
            }
        } else if (e.getSource() == sparklingStreamButton) {
            JOptionPane.showMessageDialog(this, "You chose the path along the sparkling stream.\nThe gentle sound of water soothes your soul.");
            String choice = (String) JOptionPane.showInputDialog(this,
                    "As you stroll by the stream, you encounter a group of wise sages meditating under a banyan tree.\nWhat will you do?",
                    "Choose an option",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    new String[]{"Seek their guidance", "Continue on your path"},
                    "Seek their guidance");
            if (choice != null) {
                if (choice.equals("Seek their guidance")) {
                    JOptionPane.showMessageDialog(this, "The sages impart their wisdom upon you and bless your journey.\nYou feel enlightened and ready to face any challenge ahead.\nCongratulations! Your quest for knowledge has begun!");
                } else if (choice.equals("Continue on your path")) {
                    JOptionPane.showMessageDialog(this, "You continue on your path, but the teachings of the sages resonate within you.\nYour journey continues...");
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new TextAdventureGame();
            }
        });
    }
}
